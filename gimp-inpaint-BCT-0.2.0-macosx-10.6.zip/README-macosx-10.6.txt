Gimp Plug-in for "Inpainting"

TODO

