Gimp Plug-in for "Image Registration"
http://gimp-image-reg.sourceforge.net/

This is the binary distribution of 'gimp-inpaint-BCT-0.2.0'
for Mac OS X 10.6. To install this package, unpack the contents of
this zip file into your *personal* gimp-2.x directory named:

  ~/Library/Application\ Support/Gimp

After installing the files and restarting Gimp, the plug-in will be
available as "Image Registration..." under the menu "Tools".

Please note, that currently there is no uninstaller for this package.
Therefore, for uninstalling the package you must manually remove
the files listed here:

