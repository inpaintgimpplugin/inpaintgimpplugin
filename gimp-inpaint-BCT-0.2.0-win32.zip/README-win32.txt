Gimp Plug-in for "Inpainting"

TODO


.
|-- plug-ins
|   `-- gimp-inpaint-BCT.exe
|-- README.txt
|-- README-win32.txt
`-- share
    `-- gimp-inpaint-BCT
        `-- help
            |-- en
            |   |-- gimp-help.xml
            |   `-- index.html
            `-- images
                `-- wilber.png

6 directories, 6 files
