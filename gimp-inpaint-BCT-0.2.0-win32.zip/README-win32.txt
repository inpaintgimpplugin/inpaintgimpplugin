Gimp Plug-in for "Inpainting"

This zip file contains a pre-compiled binary of the inpainting Gimp Plug-in 
(http://martinjrobins.github.io/inpaintGimpPlugin/). This comes as a zip file
which should be extracted into your GIMP user directory. 
For example, C:\Users\username\.gimp-2.8\ would be the correct directory for
user "username" and GIMP version 2.8.


.
|-- plug-ins
|   `-- gimp-inpaint-BCT.exe
|-- README.txt
|-- README-win32.txt
`-- share
    `-- gimp-inpaint-BCT
        `-- help
            |-- en
            |   |-- gimp-help.xml
            |   `-- index.html
            `-- images
                `-- wilber.png

6 directories, 6 files
