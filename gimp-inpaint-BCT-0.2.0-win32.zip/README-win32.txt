Gimp Plug-in for "Inpainting"

TODO


.
|-- plug-ins
|   `-- gimp-inpaint-BCT.exe
|-- README.txt
|-- README-win32.txt
`-- share
    |-- gimp-inpaint-BCT
    |   `-- help
    |       |-- en
    |       |   |-- gimp-help.xml
    |       |   `-- index.html
    |       `-- images
    |           `-- wilber.png
    `-- locale
        |-- az
        |   `-- LC_MESSAGES
        |       `-- gimp-inpaint-BCT.mo
        |-- de
        |   `-- LC_MESSAGES
        |       `-- gimp-inpaint-BCT.mo
        |-- fr
        |   `-- LC_MESSAGES
        |       `-- gimp-inpaint-BCT.mo
        |-- sk
        |   `-- LC_MESSAGES
        |       `-- gimp-inpaint-BCT.mo
        |-- sv
        |   `-- LC_MESSAGES
        |       `-- gimp-inpaint-BCT.mo
        `-- zh_TW
            `-- LC_MESSAGES
                `-- gimp-inpaint-BCT.mo

19 directories, 12 files
