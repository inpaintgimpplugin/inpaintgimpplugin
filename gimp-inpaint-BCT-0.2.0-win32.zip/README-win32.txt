Gimp Plug-in for "Inpainting"

This zip file contains a pre-compiled binary of the inpainting Gimp Plug-in 
(http://martinjrobins.github.io/inpaintGimpPlugin/). This comes as a zip file
which should be extracted into your GIMP user directory. 
For example, C:\Users\username\.gimp-2.8\ would be the correct directory for
user "username" and GIMP version 2.8.


.
|-- plug-ins
|   `-- gimp-inpaint-BCT.exe
|-- README.txt
|-- README-win32.txt
`-- share
    `-- gimp-inpaint-BCT
        `-- help
            |-- en
            |   |-- doc.html
            |   |-- gimp-help.xml
            |   `-- stylesheets
            |       |-- pygment_trac.css
            |       `-- stylesheet.css
            `-- images
                |-- blacktocat.png
                |-- icon_download.png
                |-- sprite_download2.png
                `-- sprite_download.png

7 directories, 11 files
