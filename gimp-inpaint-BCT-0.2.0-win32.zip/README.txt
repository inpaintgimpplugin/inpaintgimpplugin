GIMP InPainting Plug-In
=====================
Copyright (C) 2013 Thomas März (maerz@maths.ox.ac.uk) & Martin Robinson (martin.robinson@maths.ox.ac.uk)

To build the plug-in and install for all users

	./configure
	make
	sudo make install

if you want to install in the local user directory

	./configure --enable-user-install
	make
	make install

Then fire up GIMP and the plug-in will be located under Filters->Misc->Inpainting...
 
	
Batch scripting
===============

The "example" sub-directory contains an example batch script.
You first need to copy this to your script directory...

	cp example/batch_script.scm ~/.gimp-2.6/scripts/
	
Then you can call this using gimp in batch mode. For example...

	gimp -i -b '(simple-inpaint "newOrleans.png" "newOrleans_mask_bw.png" "output.png")' -b '(gimp-quit 0)'
	
Note that the example images "newOrleans.png" and "newOrleans_mask_bw.png"
are also in the "\example" sub-directory.



	
	
