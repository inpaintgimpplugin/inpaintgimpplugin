Gimp Plug-in for "Image Registration"
http://gimp-image-reg.sourceforge.net/

This is the binary distribution of 'inpaint-BCT-0.2.0'
for Win32. To install this package, unpack the contents of this zip
file into your *personal* gimp-2.x directory, which is presumably
named something like:

  c:\Documents and Settings\{user}\.gimp-2.6 (Windows 2000/XP) 
  c:\Users\{user}\.gimp-2.6                  (Windows 7, Windows Vista)

After installing the files and restarting Gimp, the plug-in will be
available as "Image Registration..." under the menu "Tools".

Please note, that currently there is no uninstaller for this package.
Therefore, for uninstalling the package you must manually remove
the files listed here:

.
|-- plug-ins
|   `-- inpaint-BCT.exe
|-- README.txt
|-- README-win32.txt
`-- share
    |-- inpaint-BCT
    |   `-- help
    |       |-- en
    |       |   |-- gimp-help.xml
    |       |   `-- index.html
    |       `-- images
    |           `-- wilber.png
    `-- locale
        |-- az
        |   `-- LC_MESSAGES
        |       `-- gimp20-plugin-template.mo
        |-- de
        |   `-- LC_MESSAGES
        |       `-- gimp20-plugin-template.mo
        |-- fr
        |   `-- LC_MESSAGES
        |       `-- gimp20-plugin-template.mo
        |-- sk
        |   `-- LC_MESSAGES
        |       `-- gimp20-plugin-template.mo
        |-- sv
        |   `-- LC_MESSAGES
        |       `-- gimp20-plugin-template.mo
        `-- zh_TW
            `-- LC_MESSAGES
                `-- gimp20-plugin-template.mo

19 directories, 12 files
